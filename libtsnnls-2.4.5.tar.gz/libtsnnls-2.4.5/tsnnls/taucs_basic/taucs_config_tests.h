/* Definition for BLAS functions */
#define TAUCS_BLAS_UNDERSCORE
